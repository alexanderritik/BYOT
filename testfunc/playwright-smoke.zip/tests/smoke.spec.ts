import { test, expect } from '@playwright/test';

test('TodoMVC smoke test', async ({ page }) => {
  await page.goto('https://demo.playwright.dev/todomvc/');

  await expect(
    page.getByRole('heading', { name: 'todos' })
  ).toBeVisible();

  const todoInput = page.getByPlaceholder('What needs to be done?');

  await todoInput.fill('Buy groceries');
  await todoInput.press('Enter');

  await todoInput.fill('Learn Playwright');
  await todoInput.press('Enter');

  await expect(page.getByRole('listitem')).toHaveCount(2);

  const groceriesTodo = page
    .getByRole('listitem')
    .filter({ hasText: 'Buy groceries' });

  await groceriesTodo.getByRole('checkbox').check();

  await page.getByRole('link', { name: 'Completed' }).click();

  await expect(page.getByRole('listitem')).toHaveCount(1);
  await expect(page.getByRole('listitem')).toContainText('Buy groceries');
});
